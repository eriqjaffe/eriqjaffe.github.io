bl_info = {
    "name": "OOTP Ballpark Toolkit",
    "author": "Eriq Jaffe",
    "version": (0, 2),
    "blender": (4, 0, 0),
    "location": "3D Viewport > Main Top Bar (Next to Object Menu)",
    "description": "Custom workflow utilities for Out of the Park Baseball stadium creation.",
    "category": "3D View",
}

import bpy
import os
import re
from bpy_extras.io_utils import ExportHelper

# ====================================================================
# OPERATOR 1: Global Scene Cleanup (Renamed Class & ID)
# ====================================================================
class OOTP_OT_scene_cleaner(bpy.types.Operator):
    """Purge DefaultMaterial geometry and isolate valid textures globally"""
    bl_idname = "ootp.scene_cleaner"
    bl_label = "Clean Scene & Isolate Materials"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        
        if bpy.ops.object.mode_set.poll():
            bpy.ops.object.mode_set(mode='OBJECT')

        mesh_count = 0
        for obj in context.scene.objects:
            if "nobake" in obj.name.lower():
                continue
            
            if obj.type == 'MESH':
                mesh_count += 1
                display_name = obj.name
                if display_name.startswith("C-"):
                    display_name = display_name.replace("C-", "", 1)
                    
                default_slot_indices = [i for i, slot in enumerate(obj.material_slots) if slot.material and slot.material.name == "DefaultMaterial"]
                
                if default_slot_indices:
                    mesh = obj.data
                    faces_to_delete = [f.index for f in mesh.polygons if f.material_index in default_slot_indices]
                    
                    if faces_to_delete:
                        context.view_layer.objects.active = obj
                        bpy.ops.object.mode_set(mode='EDIT')
                        bpy.ops.mesh.select_all(action='DESELECT')
                        bpy.ops.object.mode_set(mode='OBJECT')
                        for f_idx in faces_to_delete:
                            mesh.polygons[f_idx].select = True
                            
                        bpy.ops.object.mode_set(mode='EDIT')
                        bpy.ops.mesh.delete(type='FACE')
                        bpy.ops.object.mode_set(mode='OBJECT')
                    
                    for idx in sorted(default_slot_indices, reverse=True):
                        obj.active_material_index = idx
                        bpy.ops.object.material_slot_remove()

                for slot in obj.material_slots:
                    if slot.material:
                        orig_name = slot.material.name
                        if "." in orig_name and orig_name.split(".")[-1].isdigit():
                            orig_name = ".".join(orig_name.split(".")[:-1])
                        
                        new_mat = slot.material.copy()
                        new_mat.name = f"{orig_name}_{display_name}"
                        slot.material = new_mat

        self.report({'INFO'}, f"Processed {mesh_count} components. Purged hidden geometry & isolated materials!")
        return {'FINISHED'}


# ====================================================================
# OPERATOR 2: Node Cloner (Renamed Class & ID to bypass cache)
# ====================================================================
class OOTP_OT_node_cloner(bpy.types.Operator):
    """Clone selected shader nodes to all other materials on the active component"""
    bl_idname = "ootp.node_cloner"
    bl_label = "Clone Nodes to Component Materials"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "Please select your stadium component mesh first!")
            return {'CANCELLED'}
            
        active_mat = obj.active_material
        if not active_mat or not active_mat.use_nodes:
            self.report({'ERROR'}, "Active material must use nodes")
            return {'CANCELLED'}

        selected_nodes = [n for n in active_mat.node_tree.nodes if n.select]
        master_active = active_mat.node_tree.nodes.active

        if not selected_nodes:
            self.report({'WARNING'}, "No nodes selected in the Shader Editor!")
            return {'CANCELLED'}

        for mat_slot in obj.material_slots:
            mat = mat_slot.material
            if mat and mat != active_mat and mat.use_nodes:
                nodes = mat.node_tree.nodes
                for n in nodes:
                    n.select = False
                
                target_active_node = None
                for src_node in selected_nodes:
                    new_node = nodes.new(type=src_node.bl_idname)
                    if hasattr(src_node, "image"):
                        new_node.image = src_node.image
                    if hasattr(src_node, "uv_map"):
                        new_node.uv_map = src_node.uv_map
                        
                    new_node.location = src_node.location
                    new_node.select = True
                    if src_node == master_active:
                        target_active_node = new_node
                
                if target_active_node:
                    nodes.active = target_active_node

        self.report({'INFO'}, f"Nodes cloned across all materials for {obj.name}!")
        return {'FINISHED'}

# ====================================================================
# OPERATOR 3: Remove materials and add a new material to import baked texture
# ====================================================================
class OOTP_OT_setup_ootp_material(bpy.types.Operator):
    """Strip materials, rename based on object (minus 'C-'), and wire up a UV-linked Texture Node"""
    bl_idname = "ootp.setup_ootp_material"
    bl_label = "Setup OOTP Material"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        # Only enable the button if a mesh object is active
        return context.active_object is not None and context.active_object.type == 'MESH'

    def execute(self, context):
        obj = context.active_object
        
        obj_name = obj.name
        mat_name = obj_name[2:] if obj_name.startswith("C-") else obj_name
        
        obj.data.materials.clear()
        
        new_mat = bpy.data.materials.new(name=mat_name)
        new_mat.use_nodes = True
        nodes = new_mat.node_tree.nodes
        links = new_mat.node_tree.links
        
        nodes.clear()

        node_output  = nodes.new(type='ShaderNodeOutputMaterial')
        node_principled = nodes.new(type='ShaderNodeBsdfPrincipled')
        node_texture = nodes.new(type='ShaderNodeTexImage')
        node_uvmap   = nodes.new(type='ShaderNodeUVMap')
        
        node_uvmap.location = (-600, 0)
        node_texture.location = (-300, 0)
        node_principled.location = (0, 0)
        node_output.location = (300, 0)
        
        active_uv = obj.data.uv_layers.active
        if active_uv:
            node_uvmap.uv_map = active_uv.name

        links.new(node_uvmap.outputs['UV'], node_texture.inputs['Vector'])
        links.new(node_texture.outputs['Color'], node_principled.inputs['Base Color'])
        links.new(node_principled.outputs['BSDF'], node_output.inputs['Surface'])

        obj.data.materials.append(new_mat)
        
        self.report({'INFO'}, f"Configured material '{mat_name}' for '{obj_name}'")
        return {'FINISHED'}

# ====================================================================
# OPERATOR 4: OOTP OBJ export with crowd replacements
# ====================================================================        
class WM_OT_ootp_ballpark_exporter(bpy.types.Operator, ExportHelper):
    """Export OBJ for OOTP and automatically swap out crowd material blocks in the MTL file"""
    bl_idname = "wm.export_ootp_ballpark"
    bl_label = "Export OOTP Ballpark (.obj)"
    
    filename_ext = ".obj"
    filter_glob: bpy.props.StringProperty(default="*.obj", options={'HIDDEN'})

    def execute(self, context):
        obj_filepath = self.filepath
        export_dir = os.path.dirname(obj_filepath)
        mtl_filepath = obj_filepath.replace(".obj", ".mtl")
        
        for obj in context.scene.objects:
            if "nobake" in obj.name.lower() and obj.type == 'MESH':
                for slot in obj.material_slots:
                    if slot.material and slot.material.use_nodes:
                        for node in slot.material.node_tree.nodes:
                            # Find image texture nodes
                            if node.type == 'TEX_IMAGE' and node.image:
                                img = node.image
                                # Determine the target path inside the export folder
                                target_img_path = os.path.join(export_dir, os.path.basename(img.filepath))
                                
                                # If the image is packed inside Blender, unpack it directly to our folder
                                if img.packed_file:
                                    img.unpack(method='WRITE_LOCAL')
                                # If it's a virtual/cached path, save a real copy out to disk
                                else:
                                    try:
                                        img.save_render(target_img_path)
                                    except Exception:
                                        # Fallback if save_render fails
                                        pass
        
        bpy.ops.wm.obj_export(
            filepath=obj_filepath,
            export_selected_objects=False,  # Set to True if you only want selected exported
            export_animation=False,
            export_pbr_extensions=False,    # Keeps standard MTL format readable by OOTP
            path_mode='COPY',               
            forward_axis='NEGATIVE_Z',       
            up_axis='Y',
            export_triangulated_mesh=True   # Locks in the triangulated faces auto-fix
        )
        
        if os.path.exists(mtl_filepath):
            try:
                with open(mtl_filepath, 'r', encoding='utf-8') as f:
                    mtl_content = f.read()

                replacements = [
                    # --- BLUE ---
                    {
                        "pattern": r"newmtl seating_attendance4_blue\b.*?(?=\n\n|\Z)",
                        "replacement": "newmtl seating_attendance4_blue\nKa 0.000000 0.000000 0.000000\nKd 0.380392 0.384314 0.364706\nKs 0.000000 0.000000 0.000000\nNi 1.000000\nd 1.000000\nillum 1\nmap_Kd ../../attendance/seating_popularity4_blue.jpg"
                    },
                    {
                        "pattern": r"newmtl seating_attendance3_blue\b.*?(?=\n\n|\Z)",
                        "replacement": "newmtl seating_attendance3_blue\nKa 0.000000 0.000000 0.000000\nKd 0.364706 0.376471 0.352941\nKs 0.000000 0.000000 0.000000\nNi 1.000000\nd 1.000000\nillum 1\nmap_Kd ../../attendance/seating_popularity3_blue.jpg"
                    },
                    {
                        "pattern": r"newmtl seating_attendance2_blue\b.*?(?=\n\n|\Z)",
                        "replacement": "newmtl seating_attendance2_blue\nKa 0.000000 0.000000 0.000000\nKd 0.345098 0.380392 0.415686\nKs 0.000000 0.000000 0.000000\nNi 1.000000\nd 1.000000\nillum 1\nmap_Kd ../../attendance/seating_popularity2_blue.jpg"
                    },
                    {
                        "pattern": r"newmtl seating_attendance1_blue\b.*?(?=\n\n|\Z)",
                        "replacement": "newmtl seating_attendance1_blue\nKa 0.000000 0.000000 0.000000\nKd 0.309804 0.360784 0.419608\nKs 0.000000 0.000000 0.000000\nNi 1.000000\nd 1.000000\nillum 1\nmap_Kd ../../attendance/seating_popularity1_blue.jpg"
                    },
                    
                    # --- RED ---
                    {
                        "pattern": r"newmtl seating_attendance4_red\b.*?(?=\n\n|\Z)",
                        "replacement": "newmtl seating_attendance4_red\nKa 0.000000 0.000000 0.000000\nKd 0.380392 0.384314 0.364706\nKs 0.000000 0.000000 0.000000\nNi 1.000000\nd 1.000000\nillum 1\nmap_Kd ../../attendance/seating_popularity4_red.jpg"
                    },
                    {
                        "pattern": r"newmtl seating_attendance3_red\b.*?(?=\n\n|\Z)",
                        "replacement": "newmtl seating_attendance3_red\nKa 0.000000 0.000000 0.000000\nKd 0.364706 0.376471 0.352941\nKs 0.000000 0.000000 0.000000\nNi 1.000000\nd 1.000000\nillum 1\nmap_Kd ../../attendance/seating_popularity3_red.jpg"
                    },
                    {
                        "pattern": r"newmtl seating_attendance2_red\b.*?(?=\n\n|\Z)",
                        "replacement": "newmtl seating_attendance2_red\nKa 0.000000 0.000000 0.000000\nKd 0.345098 0.380392 0.415686\nKs 0.000000 0.000000 0.000000\nNi 1.000000\nd 1.000000\nillum 1\nmap_Kd ../../attendance/seating_popularity2_red.jpg"
                    },
                    {
                        "pattern": r"newmtl seating_attendance1_red\b.*?(?=\n\n|\Z)",
                        "replacement": "newmtl seating_attendance1_red\nKa 0.000000 0.000000 0.000000\nKd 0.309804 0.360784 0.419608\nKs 0.000000 0.000000 0.000000\nNi 1.000000\nd 1.000000\nillum 1\nmap_Kd ../../attendance/seating_popularity1_red.jpg"
                    },

                    # --- GREY ---
                    {
                        "pattern": r"newmtl seating_attendance4_grey\b.*?(?=\n\n|\Z)",
                        "replacement": "newmtl seating_attendance4_grey\nKa 0.000000 0.000000 0.000000\nKd 0.380392 0.384314 0.364706\nKs 0.000000 0.000000 0.000000\nNi 1.000000\nd 1.000000\nillum 1\nmap_Kd ../../attendance/seating_popularity4_grey.jpg"
                    },
                    {
                        "pattern": r"newmtl seating_attendance3_grey\b.*?(?=\n\n|\Z)",
                        "replacement": "newmtl seating_attendance3_grey\nKa 0.000000 0.000000 0.000000\nKd 0.364706 0.376471 0.352941\nKs 0.000000 0.000000 0.000000\nNi 1.000000\nd 1.000000\nillum 1\nmap_Kd ../../attendance/seating_popularity3_grey.jpg"
                    },
                    {
                        "pattern": r"newmtl seating_attendance2_grey\b.*?(?=\n\n|\Z)",
                        "replacement": "newmtl seating_attendance2_grey\nKa 0.000000 0.000000 0.000000\nKd 0.345098 0.380392 0.415686\nKs 0.000000 0.000000 0.000000\nNi 1.000000\nd 1.000000\nillum 1\nmap_Kd ../../attendance/seating_popularity2_grey.jpg"
                    },
                    {
                        "pattern": r"newmtl seating_attendance1_grey\b.*?(?=\n\n|\Z)",
                        "replacement": "newmtl seating_attendance1_grey\nKa 0.000000 0.000000 0.000000\nKd 0.309804 0.360784 0.419608\nKs 0.000000 0.000000 0.000000\nNi 1.000000\nd 1.000000\nillum 1\nmap_Kd ../../attendance/seating_popularity1_grey.jpg"
                    },

                    # --- GREEN ---
                    {
                        "pattern": r"newmtl crowd_new_4\b.*?(?=\n\n|\Z)",
                        "replacement": "newmtl crowd_new_4\nKa 0.000000 0.000000 0.000000\nKd 0.380392 0.384314 0.364706\nKs 0.000000 0.000000 0.000000\nKe 0.000000 0.000000 0.000000\nNi 1.000000\nd 1.000000\nillum 1\nmap_Kd ../../attendance/seating_popularity4.jpg"
                    },
                    {
                        "pattern": r"newmtl Crowd_new_3\b.*?(?=\n\n|\Z)",
                        "replacement": "newmtl Crowd_new_3\nKa 0.000000 0.000000 0.000000\nKd 0.364706 0.376471 0.352941\nKs 0.000000 0.000000 0.000000\nKe 0.000000 0.000000 0.000000\nNi 1.000000\nd 1.000000\nillum 1\nmap_Kd ../../attendance/seating_popularity3.jpg"
                    },
                    {
                        "pattern": r"newmtl crowd_new_2\b.*?(?=\n\n|\Z)",
                        "replacement": "newmtl crowd_new_2\nKa 0.000000 0.000000 0.000000\nKd 0.321569 0.360784 0.309804\nKs 0.000000 0.000000 0.000000\nKe 0.000000 0.000000 0.000000\nNi 1.000000\nd 1.000000\nillum 1\nmap_Kd ../../attendance/seating_popularity2.jpg"
                    },
                    {
                        "pattern": r"newmtl crowd_new_1\b.*?(?=\n\n|\Z)",
                        "replacement": "newmtl crowd_new_1\nKa 0.000000 0.000000 0.000000\nKd 0.286275 0.349020 0.274510\nKs 0.000000 0.000000 0.000000\nKe 0.000000 0.000000 0.000000\nNi 1.000000\nd 1.000000\nillum 1\nmap_Kd ../../attendance/seating_popularity1.jpg"
                    }
                ]

                patch_count = 0
                for item in replacements:
                    if re.search(item["pattern"], mtl_content, flags=re.DOTALL):
                        mtl_content = re.sub(item["pattern"], item["replacement"], mtl_content, flags=re.DOTALL)
                        patch_count += 1

                with open(mtl_filepath, 'w', encoding='utf-8') as f:
                    f.write(mtl_content)
                    
                self.report({'INFO'}, f"Export complete. Successfully patched {patch_count} active definitions.")
                
            except Exception as e:
                self.report({'ERROR'}, f"Failed parsing MTL textures: {str(e)}")
        else:
            self.report({'WARNING'}, "OBJ Exported, but no tracking MTL found to override.")

        return {'FINISHED'}

# ====================================================================
# UI MENU
# ====================================================================
class VIEW3D_MT_ootp_custom_menu(bpy.types.Menu):
    bl_label = "OOTP"
    bl_idname = "VIEW3D_MT_ootp_custom_menu"

    def draw(self, context):
        layout = self.layout
        
        layout.operator("ootp.scene_cleaner", text="Clean Scene & Isolate Materials", icon='FILE_REFRESH')
        layout.operator("ootp.node_cloner", text="Clone Nodes to Component Materials", icon='DUPLICATE')
        layout.operator("ootp.setup_ootp_material", text="Set Up OOTP Material", icon='MATERIAL')
        layout.separator()
        layout.operator("wm.export_ootp_ballpark", text="Export Ballpark to OOTP", icon='EXPORT')


def draw_menu_header(self, context):
    if context.mode == 'OBJECT':
        layout = self.layout
        layout.menu("VIEW3D_MT_ootp_custom_menu")

def register():
    bpy.utils.register_class(OOTP_OT_scene_cleaner)
    bpy.utils.register_class(OOTP_OT_node_cloner)
    bpy.utils.register_class(OOTP_OT_setup_ootp_material)
    bpy.utils.register_class(WM_OT_ootp_ballpark_exporter)
    bpy.utils.register_class(VIEW3D_MT_ootp_custom_menu)
    bpy.types.VIEW3D_MT_editor_menus.append(draw_menu_header)

def unregister():
    bpy.types.VIEW3D_MT_editor_menus.remove(draw_menu_header)
    bpy.utils.unregister_class(VIEW3D_MT_ootp_custom_menu)
    bpy.utils.unregister_class(WM_OT_ootp_ballpark_exporter)
    bpy.utils.unregister_class(OOTP_OT_setup_ootp_material)
    bpy.utils.unregister_class(OOTP_OT_node_cloner)
    bpy.utils.unregister_class(OOTP_OT_scene_cleaner)

if __name__ == "__main__":
    register()