bl_info = {
    "name": "OOTP Ballpark Toolkit",
    "author": "Eriq Jaffe",
    "version": (0, 1),
    "blender": (4, 0, 0),
    "location": "3D Viewport > Main Top Bar (Next to Object Menu)",
    "description": "Custom workflow utilities for Out of the Park Baseball stadium creation.",
    "category": "3D View",
}

import bpy

# ====================================================================
# OPERATOR 1: Global Scene Cleanup (Renamed Class & ID)
# ====================================================================
class OOTP_OT_scene_cleaner(bpy.types.Operator):
    """Purge DefaultMaterial geometry and isolate valid textures globally"""
    bl_idname = "ootp.scene_cleaner"
    bl_label = "Clean Scene & Isolate Materials"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        if bpy.ops.object.mode_set.poll():
            bpy.ops.object.mode_set(mode='OBJECT')

        mesh_count = 0
        for obj in context.scene.objects:
            if obj.type == 'MESH':
                mesh_count += 1
                display_name = obj.name
                if display_name.startswith("C-"):
                    display_name = display_name.replace("C-", "", 1)
                    
                default_slot_indices = [i for i, slot in enumerate(obj.material_slots) if slot.material and slot.material.name == "DefaultMaterial"]
                
                if default_slot_indices:
                    mesh = obj.data
                    faces_to_delete = [f.index for f in mesh.polygons if f.material_index in default_slot_indices]
                    
                    if faces_to_delete:
                        context.view_layer.objects.active = obj
                        bpy.ops.object.mode_set(mode='EDIT')
                        bpy.ops.mesh.select_all(action='DESELECT')
                        bpy.ops.object.mode_set(mode='OBJECT')
                        for f_idx in faces_to_delete:
                            mesh.polygons[f_idx].select = True
                            
                        bpy.ops.object.mode_set(mode='EDIT')
                        bpy.ops.mesh.delete(type='FACE')
                        bpy.ops.object.mode_set(mode='OBJECT')
                    
                    for idx in sorted(default_slot_indices, reverse=True):
                        obj.active_material_index = idx
                        bpy.ops.object.material_slot_remove()

                for slot in obj.material_slots:
                    if slot.material:
                        orig_name = slot.material.name
                        if "." in orig_name and orig_name.split(".")[-1].isdigit():
                            orig_name = ".".join(orig_name.split(".")[:-1])
                        
                        new_mat = slot.material.copy()
                        new_mat.name = f"{orig_name}_{display_name}"
                        slot.material = new_mat

        self.report({'INFO'}, f"Processed {mesh_count} components. Purged hidden geometry & isolated materials!")
        return {'FINISHED'}


# ====================================================================
# OPERATOR 2: Node Cloner (Renamed Class & ID to bypass cache)
# ====================================================================
class OOTP_OT_node_cloner(bpy.types.Operator):
    """Clone selected shader nodes to all other materials on the active component"""
    bl_idname = "ootp.node_cloner"
    bl_label = "Clone Nodes to Component Materials"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "Please select your stadium component mesh first!")
            return {'CANCELLED'}
            
        active_mat = obj.active_material
        if not active_mat or not active_mat.use_nodes:
            self.report({'ERROR'}, "Active material must use nodes")
            return {'CANCELLED'}

        selected_nodes = [n for n in active_mat.node_tree.nodes if n.select]
        master_active = active_mat.node_tree.nodes.active

        if not selected_nodes:
            self.report({'WARNING'}, "No nodes selected in the Shader Editor!")
            return {'CANCELLED'}

        for mat_slot in obj.material_slots:
            mat = mat_slot.material
            if mat and mat != active_mat and mat.use_nodes:
                nodes = mat.node_tree.nodes
                for n in nodes:
                    n.select = False
                
                target_active_node = None
                for src_node in selected_nodes:
                    new_node = nodes.new(type=src_node.bl_idname)
                    if hasattr(src_node, "image"):
                        new_node.image = src_node.image
                    if hasattr(src_node, "uv_map"):
                        new_node.uv_map = src_node.uv_map
                        
                    new_node.location = src_node.location
                    new_node.select = True
                    if src_node == master_active:
                        target_active_node = new_node
                
                if target_active_node:
                    nodes.active = target_active_node

        self.report({'INFO'}, f"Nodes cloned across all materials for {obj.name}!")
        return {'FINISHED'}


# ====================================================================
# UI MENU
# ====================================================================
class VIEW3D_MT_ootp_custom_menu(bpy.types.Menu):
    bl_label = "OOTP"
    bl_idname = "VIEW3D_MT_ootp_custom_menu"

    def draw(self, context):
        layout = self.layout
        
        # Explicitly drawing with custom labels to prevent fallback blanks
        layout.operator("ootp.scene_cleaner", text="Clean Scene & Isolate Materials", icon='FILE_REFRESH')
        layout.operator("ootp.node_cloner", text="Clone Nodes to Component Materials", icon='DUPLICATE')


def draw_menu_header(self, context):
    if context.mode == 'OBJECT':
        layout = self.layout
        layout.menu("VIEW3D_MT_ootp_custom_menu")

def register():
    bpy.utils.register_class(OOTP_OT_scene_cleaner)
    bpy.utils.register_class(OOTP_OT_node_cloner)
    bpy.utils.register_class(VIEW3D_MT_ootp_custom_menu)
    bpy.types.VIEW3D_MT_editor_menus.append(draw_menu_header)

def unregister():
    bpy.types.VIEW3D_MT_editor_menus.remove(draw_menu_header)
    bpy.utils.unregister_class(VIEW3D_MT_ootp_custom_menu)
    bpy.utils.unregister_class(OOTP_OT_node_cloner)
    bpy.utils.unregister_class(OOTP_OT_scene_cleaner)

if __name__ == "__main__":
    register()